"""Capture untouched simulator pixels before a synthetic readback returns.

This wraps the fixed local audit server without changing its data or the app.
The XCTest caller waits for the readback, so Done cannot race the screenshot.
Only the two keyboard checkpoints on a dedicated fixture simulator are eligible.
"""
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import hashlib
import json
import runpy
import subprocess
import sys
import time

flag = sys.argv.index('--snapshot-dir')
destination = Path(sys.argv[flag + 1])
del sys.argv[flag:flag + 2]
device = sys.argv[sys.argv.index('--ui-device') + 1]
assert device in ['922E011C-3895-4DB1-9C9A-1D3A977226CF', 'AF849DEA-DF34-4B0E-9FC1-3E45DCBE8481']
assert destination.is_absolute() and not destination.exists()
destination.mkdir()
original_end_headers = BaseHTTPRequestHandler.end_headers
records = []

def end_headers(self):
    parts = urlsplit(self.path)
    checkpoint = parse_qs(parts.query).get('checkpoint', [''])[0]
    if (parts.path == '/ui-state'
            and checkpoint in ['keyboard-touched-key', 'keyboard-done']
            and self._headers_buffer[0].split()[1] == b'200'):
        root = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', device, 'com.dbakp.lumen', 'data'], text=True, timeout=5).strip())
        state = json.loads((root / 'tmp/Lumen-provider-ui-live.json').read_text())
        assert state['apiKeyClass'] in ['fixture-a', 'fixture-b', 'missing']
        name = str(len(records)) + '-' + checkpoint + '.png'
        image = destination / name
        captured = time.time()
        subprocess.run(['xcrun', 'simctl', 'io', device, 'screenshot', str(image)], check=True, timeout=8)
        records.append({'checkpoint': checkpoint, 'capturedAt': captured, 'device': device,
                        'state': state, 'file': name, 'sha256': hashlib.sha256(image.read_bytes()).hexdigest()})
        (destination / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
    return original_end_headers(self)

BaseHTTPRequestHandler.end_headers = end_headers
runpy.run_path('/Users/davidbakposada/Documents/ChatGPT/Lumen/scripts/provider-authorization-server.py', run_name='__main__')
