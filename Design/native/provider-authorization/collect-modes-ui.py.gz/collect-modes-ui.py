from pathlib import Path
import sys, json, gzip, hashlib, shutil, subprocess

revision = int(sys.argv[1])
raw = Path('/tmp/LumenBatch42Checks')
base = Path('/Users/davidbakposada/Documents/ChatGPT/Lumen/Design/native/provider-authorization')
stem = sys.argv[2] if len(sys.argv) > 2 else f'ConnectionModesUIR{revision}'
prefix = sys.argv[3] if len(sys.argv) > 3 else f'connection-modes-ui-r{revision}'
server_stem = sys.argv[4] if len(sys.argv) > 4 else f'ConnectionModesUIServerR{revision}'
export = raw / (stem + 'Attachments')
summary = json.loads(subprocess.check_output(['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', str(raw / (stem + '.xcresult')), '--compact']))
if not export.exists():
    result = subprocess.run(['xcrun', 'xcresulttool', 'export', 'attachments', '--path', str(raw / (stem + '.xcresult')), '--output-path', str(export)], capture_output=True)
    (raw / (stem + 'Export.log')).write_bytes(result.stdout + result.stderr)
    result.check_returncode()
manifest = json.loads((export / 'manifest.json').read_text())
host = json.loads((raw / (server_stem + '.json')).read_text())
images, reads = [], []
for test in manifest:
    for a in test['attachments']:
        name = a['suggestedHumanReadableName']
        path = export / a['exportedFileName']
        if name.startswith('provider-ui-') and name.endswith('.json'):
            reads.append({'testIdentifier': test['testIdentifier'], 'attachment': name, 'data': json.loads(path.read_text())})
        if name.endswith('.png'):
            destination = base / name
            shutil.copyfile(path, destination)
            data = destination.read_bytes()
            images.append({'repositoryPath': str(destination.relative_to(base.parents[2])), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'testIdentifier': test['testIdentifier'], 'timestamp': a['timestamp']})
assert len(reads) == len(host['uiReadbacks'])
assert all(any(r['data'] == h['state'] for h in host['uiReadbacks']) for r in reads)
for suffix, value in [('summary', summary), ('host-readback', host), ('xctest-readbacks', reads), ('images', images)]:
    (base / (prefix + '-' + suffix + '.json')).write_text(json.dumps(value, indent=2) + '\n')
for name in [stem + '.log', stem + 'Export.log', server_stem + '.log', f'ConnectionModesBuildR{revision}.log']:
    if (raw / name).exists():
        (base / (name + '.gz')).write_bytes(gzip.compress((raw / name).read_bytes(), mtime=0))
identity = base / f'connection-ui-r{revision}-identity.json'
if identity.exists():
    obj = json.loads(identity.read_text())
    obj['runtimeAcceptance'] = 'scoped-test-passed' if summary['failedTests'] == 0 else 'failed-not-accepted'
    identity.write_text(json.dumps(obj, indent=2) + '\n')
print(json.dumps({'revision': revision, 'passed': summary['passedTests'], 'failed': summary['failedTests'], 'images': len(images), 'matchedReadbacks': len(reads), 'runtimeWarnings': summary.get('runtimeWarnings', [])}))
