from pathlib import Path
import gzip, hashlib, json, shutil, signal, subprocess, time, urllib.request

repo = Path('/Users/davidbakposada/Documents/ChatGPT/Lumen')
raw = Path('/tmp/LumenBatch42Checks')
saved = repo / 'Design/native/provider-authorization'
device = 'AF849DEA-DF34-4B0E-9FC1-3E45DCBE8481'
binary = Path('/tmp/LumenBatch37Simulator/Build/Products/Debug-iphonesimulator/Lumen.app/Lumen')
expected_binary = '78bab382ebc2a2e2d375230e5b72091f33cd70e2b182d0384742f26d4e3ddd53'
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_binary
source = json.loads((saved / 'connection-source-r41.json').read_text())
assert all(hashlib.sha256((repo / f).read_bytes()).hexdigest() == row['sha256'] for f, row in source['files'].items())
assert shutil.disk_usage(repo).free > 15_000_000_000
cases = [
    ('auth', 'testProviderAuthorizationChecks', 'authorization', 'Provider authorization checks passed', 27, 17, 5, 0),
    ('signin', 'testProviderSignInChecks', 'signin', 'Provider sign-in checks passed', 16, 0, 0, 10),
    ('token-transport', 'testProviderTokenTransportChecks', 'token-transport', 'Token transport checks passed', 45, 0, 5, 0),
    ('caller', 'testProviderCallerChecks', 'caller', 'Provider caller checks passed', 33, 0, 20, 0),
]
receipts = []
for kind, test, report_name, status, count, tokens, packets, logins in cases:
    stem = 'FinalProviderR47-' + kind
    host_path = raw / (stem + '-host.json')
    server_log = raw / (stem + '-server.log')
    with server_log.open('wb') as output:
        server = subprocess.Popen(['python3', 'scripts/provider-authorization-server.py', '--report', str(host_path)], cwd=repo, stdout=output, stderr=subprocess.STDOUT)
        try:
            for attempt in range(50):
                assert server.poll() is None, 'Fresh host exited'
                try:
                    with urllib.request.urlopen('http://127.0.0.1:48733/audit', timeout=1) as response:
                        initial = json.load(response)
                    break
                except OSError:
                    time.sleep(0.1)
            else:
                raise AssertionError('Fresh host did not become ready')
            assert not initial['packets'] and initial['tokenRequests'] == initial['loginRequests'] == 0
            started = time.time()
            log_path = raw / (stem + '.log')
            bundle = raw / (stem + '.xcresult')
            assert not bundle.exists(), 'Do not overwrite an existing run'
            command = ['xcodebuild', 'test-without-building', '-xctestrun', '/tmp/LumenBatch37Simulator/Build/Products/Lumen_Lumen_iphonesimulator27.0-arm64-x86_64.xctestrun', '-destination', 'platform=iOS Simulator,id=' + device, '-parallel-testing-enabled', 'NO', '-collect-test-diagnostics', 'never', '-only-testing:LumenUITests/LumenSmokeTests/' + test, '-resultBundlePath', str(bundle)]
            print('START', stem, flush=True)
            with log_path.open('wb') as log:
                result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
            with urllib.request.urlopen('http://127.0.0.1:48733/audit', timeout=3) as response:
                host = json.load(response)
            container = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', device, 'com.dbakp.lumen', 'data'], text=True).strip())
            report_path = container / 'tmp' / ('Lumen-provider-' + report_name + '-report.json')
            assert report_path.stat().st_mtime >= started
            report = json.loads(report_path.read_text())
            prefix = kind + '-r47'
            for suffix, value in [('report', report), ('host-readback', host)]:
                (saved / (prefix + '-' + suffix + '.json')).write_text(json.dumps(value, indent=2) + '\n')
            summary = json.loads(subprocess.check_output(['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', str(bundle), '--compact']))
            (saved / (prefix + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
            export = raw / (stem + '-attachments')
            subprocess.run(['xcrun', 'xcresulttool', 'export', 'attachments', '--path', str(bundle), '--output-path', str(export)], check=True, stdout=subprocess.DEVNULL)
            images = []
            for group in json.loads((export / 'manifest.json').read_text()):
                for item in group['attachments']:
                    if item['suggestedHumanReadableName'].endswith('.png'):
                        destination = saved / item['suggestedHumanReadableName']
                        shutil.copyfile(export / item['exportedFileName'], destination)
                        data = destination.read_bytes()
                        images.append({'repositoryPath': str(destination.relative_to(repo)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
            (saved / (prefix + '-images.json')).write_text(json.dumps(images, indent=2) + '\n')
            for path in [log_path, server_log]:
                (saved / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
            assert result.returncode == 0 and summary['passedTests'] == 1 and summary['failedTests'] == summary['skippedTests'] == 0
            assert report['status'] == status and report['cleanupVerified'] and len(report['observations']) == count and report['host'] == host
            assert host['tokenRequests'] == host['tokenResponses'] == tokens and len(host['packets']) == packets and host['loginRequests'] == host['loginResponses'] == logins and host['holdTimeouts'] == 0
            if kind == 'token-transport':
                assert len(host['tokenTransportAudit']) == host['tokenTransportResponses'] == 39 and host['tokenRedirectHits'] == 0
            installed = Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', device, 'com.dbakp.lumen', 'app'], text=True).strip()) / 'Lumen'
            assert hashlib.sha256(installed.read_bytes()).hexdigest() == expected_binary
            receipts.append({'kind': kind, 'observations': count, 'passedTests': 1, 'providerPackets': packets, 'binarySHA256': expected_binary, 'command': command})
            (saved / 'final-provider-r47-identity.json').write_text(json.dumps({'source': 'connection-source-r41.json', 'applicationSHA256': expected_binary, 'completedCases': receipts, 'scope': 'Current native production providers through fixed loopback only; no live account/provider acceptance'}, indent=2) + '\n')
            print('PASS', stem, count, 'native observations; exact independent host match', flush=True)
        finally:
            server.send_signal(signal.SIGINT)
            server.wait(timeout=10)
print('ALL FOUR CURRENT PROVIDER REGRESSIONS PASSED', flush=True)
