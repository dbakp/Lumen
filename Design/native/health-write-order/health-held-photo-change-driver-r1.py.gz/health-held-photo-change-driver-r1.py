"""Independent actual held JPEG source-change audit on the dedicated simulator."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--build', required=True)
p.add_argument('--trial', required=True)
p.add_argument('--mode', choices=['in-place', 'replacement'], required=True)
a = p.parse_args()
assert re.fullmatch(r'[A-Za-z0-9-]+', a.trial)
base = Path(__file__).resolve().parent
repo = base.parents[2]
raw = Path('/tmp/LumenBatch43Checks')
device = 'AF849DEA-DF34-4B0E-9FC1-3E45DCBE8481'
case = 'Mutation' if a.mode == 'in-place' else 'Replacement'
stem = 'HealthHeldPhoto' + case + a.trial
prefix = 'health-held-photo-' + a.mode + '-' + a.trial.lower()
bundle = raw / (stem + '.xcresult')
assert not bundle.exists()
sha = lambda data: hashlib.sha256(data).hexdigest()
source = json.loads((base / a.source).read_text())
build = json.loads((base / a.build).read_text())
changed = (base / 'health-backup-photo-changed-r1.jpg').read_bytes()
assert changed.startswith(b'\xff\xd8') and 0 < len(changed) < 64 * 1024


def container(kind):
    return Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', device,
                                        'com.dbakp.lumen', kind], text=True).strip())


def identity():
    assert build['source'] == a.source
    for name, row in {**source['files'], **source.get('fixtureInputs', {})}.items():
        assert sha((repo / name).read_bytes()) == row['sha256'], name
    assert sha((container('app') / 'Lumen').read_bytes()) == build['sha256']


def snapshot(root):
    assert root.is_dir() and not root.is_symlink()
    rows = {}
    total = 0
    for parent, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            assert not (Path(parent) / name).is_symlink()
        for name in files:
            f = Path(parent) / name
            facts = f.lstat()
            assert stat.S_ISREG(facts.st_mode) and facts.st_size <= 256 * 1024, f
            data = f.read_bytes()
            total += len(data)
            assert total <= 2 * 1024 * 1024
            rows[str(f.relative_to(root))] = {'bytes': len(data), 'sha256': sha(data),
                                             'base64': base64.b64encode(data).decode()}
    assert (root / 'water.json').read_bytes() == b'{"syntheticUnavailableWater":'
    return rows


started = time.time()
before = None
expected = None
observations = []
protocol = None
command = ['xcodebuild', '-project', 'Lumen.xcodeproj', '-scheme', 'Lumen', '-configuration', 'Debug',
           '-destination', 'platform=iOS Simulator,id=' + device,
           '-derivedDataPath', '/tmp/LumenBatch37Simulator',
           '-clonedSourcePackagesDirPath', '/tmp/LumenBatch37Packages', '-disableAutomaticPackageResolution',
           '-parallel-testing-enabled', 'NO', '-collect-test-diagnostics', 'never',
           '-only-testing:LumenUITests/LumenSmokeTests/testHealthRecoveryReadRetainedPhoto' + case,
           '-resultBundlePath', str(bundle), 'test-without-building']
with (raw / (stem + '.log')).open('wb') as out:
    process = subprocess.Popen(command, cwd=repo, stdout=out, stderr=subprocess.STDOUT)
    awake = subprocess.Popen(['caffeinate', '-d', '-i', '-w', str(process.pid)])
    deadline = time.monotonic() + 400
    try:
        while process.poll() is None:
            assert time.monotonic() < deadline, 'Inspect same producer; observation expiry is not terminal'
            group = container('group.com.dbakp.lumen')
            checkpoint = group / 'Lumen-health-read-checkpoint.json'
            try:
                if checkpoint.stat().st_mtime < started:
                    time.sleep(0.2)
                    continue
                protocol = json.loads(checkpoint.read_bytes())
            except (FileNotFoundError, json.JSONDecodeError):
                time.sleep(0.2)
                continue
            root = group / 'LumenData'
            assert Path(protocol['root']).resolve() == root.resolve()
            if not protocol['attempts'] or observations:
                time.sleep(0.2)
                continue
            record = protocol['attempts'][0]
            tag = 'retained-photo-' + a.mode + '-held'
            if ("Added attachment named '" + tag + "'") not in (raw / (stem + '.log')).read_text():
                time.sleep(0.2)
                continue
            identity()
            assert record['ordinal'] == 1 and record['phase'] == 'held'
            assert record['scope'] == 'retained-photo' and record['workerControlMatchesUI']
            file = Path(record['file'])
            assert not file.is_symlink() and file.resolve().is_relative_to((root / '.health-recovery').resolve())
            facts = file.lstat()
            assert stat.S_ISREG(facts.st_mode) and facts.st_ino == record['inode'] and facts.st_size == record['size']
            assert file.name == 'synthetic-review-photo.jpg'
            assert 0 < record['bytesRead'] <= min(64 * 1024, facts.st_size)
            assert Path(subprocess.check_output(['ps', '-p', str(record['pid']), '-o', 'comm='], text=True).strip()) == container('app') / 'Lumen'
            lsof = subprocess.check_output(['lsof', '-nP', '-a', '-p', str(record['pid']), '-d', str(record['descriptor']), '-Fnift'], text=True)
            assert 'tREG' in lsof and ('i' + str(record['inode'])) in lsof
            assert any(line.startswith('n') and Path(line[1:]).resolve() == file.resolve() for line in lsof.splitlines())
            before = snapshot(root)
            original = file.read_bytes()
            assert original != changed and original.startswith(b'\xff\xd8')
            current_photo = root / 'photos' / file.name
            assert current_photo.read_bytes() == original
            relative = str(file.relative_to(root))
            # In-place writes intentionally reach every existing hard-link alias.
            # Record that set independently before mutating; never call it app damage.
            aliases = [name for name in before if (root / name).stat().st_ino == facts.st_ino
                       and (root / name).stat().st_dev == facts.st_dev]
            assert relative in aliases
            affected = aliases if a.mode == 'in-place' else [relative]
            expected = dict(before)
            row = {'bytes': len(changed), 'sha256': sha(changed), 'base64': base64.b64encode(changed).decode()}
            for name in affected:
                expected[name] = row
            if a.mode == 'in-place':
                with file.open('r+b') as writer:
                    writer.write(changed)
                    writer.truncate()
                    writer.flush()
                    os.fsync(writer.fileno())
                assert file.stat().st_ino == facts.st_ino
            else:
                temporary = file.with_name(file.name + '.synthetic-replacement')
                assert not temporary.exists()
                temporary.write_bytes(changed)
                temporary.replace(file)
                assert file.stat().st_ino != facts.st_ino
            assert snapshot(root) == expected
            observations.append({'record': record.copy(), 'originalBytes': base64.b64encode(original).decode(),
                                 'originalSHA256': sha(original), 'changedSHA256': sha(changed),
                                 'openDescriptorBefore': lsof, 'aliasesBefore': aliases, 'hostChangedPaths': affected,
                                 'afterHostMutation': snapshot(root), 'newPathInode': file.stat().st_ino,
                                 'observedAfterNativeAttachment': tag})
            release = group / 'Lumen-health-read-release.json'
            temporary = group / (release.name + '.' + record['nonce'] + '.tmp')
            temporary.write_text(json.dumps({'nonce': record['nonce']}))
            temporary.replace(release)
            time.sleep(0.2)
        code = process.wait()
    finally:
        (base / (prefix + '-observations.json')).write_text(json.dumps({
            'source': a.source, 'build': a.build, 'producerPID': process.pid, 'producerExitCode': process.poll(),
            'before': before, 'expectedAfterExplicitHostChange': expected, 'heldObservations': observations,
            'protocol': protocol, 'scope': 'Dedicated synthetic simulator only; no personal phone data.'
        }, indent=2) + '\n')
summary = json.loads(subprocess.check_output(['xcrun', 'xcresulttool', 'get', 'test-results', 'summary', '--path', str(bundle)], text=True))
for destination in [raw / (stem + '-summary.json'), base / (prefix + '-summary.json')]:
    destination.write_text(json.dumps(summary, indent=2) + '\n')
assert code == 0 and summary['passedTests'] == 1 and summary['failedTests'] == 0
identity()
protocol = json.loads((container('group.com.dbakp.lumen') / 'Lumen-health-read-checkpoint.json').read_bytes())
assert len(protocol['attempts']) == len(observations) == 1
assert protocol['attempts'][0]['phase'] == 'released'
assert protocol['attempts'][0]['workerControlMatchesUI'] and protocol['attempts'][0]['descriptorCloseSucceeded']
after = snapshot(container('group.com.dbakp.lumen') / 'LumenData')
assert after == expected
(base / (prefix + '-host-audit.json')).write_text(json.dumps({
    'status': 'passed: actual held JPEG ' + a.mode + ' source change rejected; native error/no image, reader closed, only explicit host changes remain',
    'source': a.source, 'build': a.build, 'before': before, 'after': after,
    'expectedAfterExplicitHostChange': expected, 'heldObservations': observations, 'protocol': protocol,
    'producerExitCode': code, 'verifierSHA256': sha(Path(__file__).read_bytes()),
    'scope': 'One main-normal source-change window during retained photo verification. No source restoration/retry, final payload-read window, selected-file or full-contract acceptance.'
}, indent=2) + '\n')
print('PASS: actual held JPEG ' + a.mode + ' source change rejected; only explicit host changes remain')
