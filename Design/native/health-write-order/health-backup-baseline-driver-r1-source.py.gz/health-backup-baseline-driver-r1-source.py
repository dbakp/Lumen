"""Actual normal Settings/Files baseline while current Water cannot be opened."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--build', required=True)
p.add_argument('--case', choices=['legacy', 'encrypted', 'readable'], required=True)
p.add_argument('--trial', required=True)
a = p.parse_args()
assert re.fullmatch(r'[A-Za-z0-9-]+', a.trial)
base = Path(__file__).resolve().parent
repo = base.parents[2]
raw = Path('/tmp/LumenBatch43Checks')
device = 'AF849DEA-DF34-4B0E-9FC1-3E45DCBE8481'
stem = 'HealthBackupBaseline' + a.case.title() + a.trial
prefix = 'health-backup-baseline-' + a.case + '-' + a.trial.lower()
result = raw / (stem + '.xcresult')
assert not result.exists()
source = json.loads((base / a.source).read_text())
build = json.loads((base / a.build).read_text())
digest = lambda data: hashlib.sha256(data).hexdigest()

def container(kind):
    return Path(subprocess.check_output(['xcrun', 'simctl', 'get_app_container', device,
                                        'com.dbakp.lumen', kind], text=True).strip())

def identity():
    for name, row in source['files'].items():
        assert digest((repo / name).read_bytes()) == row['sha256'], name
    assert build['source'] == a.source
    assert digest((container('app') / 'Lumen').read_bytes()) == build['sha256']

def originals(group, checkpoint):
    root = group / 'LumenData'
    rows = {}
    for name, encoded in checkpoint['originals'].items():
        path = root / name
        assert stat.S_ISREG(path.lstat().st_mode)
        data = path.read_bytes()
        assert data == base64.b64decode(encoded, validate=True), name
        rows[name] = {'bytes': len(data), 'sha256': digest(data), 'base64': encoded}
    assert (root / 'water.json').read_bytes() == b'{"syntheticUnavailableWater":'
    assert not list((root / '.health-recovery-history').glob('*.json'))
    return rows

command = ['xcodebuild', '-project', 'Lumen.xcodeproj', '-scheme', 'Lumen', '-configuration', 'Debug',
           '-destination', 'platform=iOS Simulator,id=' + device,
           '-derivedDataPath', '/tmp/LumenBatch37Simulator',
           '-clonedSourcePackagesDirPath', '/tmp/LumenBatch37Packages', '-disableAutomaticPackageResolution',
           '-parallel-testing-enabled', 'NO', '-collect-test-diagnostics', 'never',
           '-only-testing:LumenUITests/LumenSmokeTests/testHealthBackupUnavailable' + a.case.title() + 'Baseline',
           '-resultBundlePath', str(result), 'test-without-building']
started = time.time()
checkpoint = None
before = None
with (raw / (stem + '.log')).open('wb') as stream:
    process = subprocess.Popen(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    awake = subprocess.Popen(['caffeinate', '-d', '-i', '-w', str(process.pid)])
    try:
        while process.poll() is None and time.time() - started < 120:
            try:
                group = container('group.com.dbakp.lumen')
                path = group / 'Lumen-health-backup-baseline.json'
                if path.stat().st_mtime >= started:
                    value = json.loads(path.read_bytes())
                    if value['case'] == a.case:
                        identity()
                        before = originals(group, value)
                        checkpoint = value
                        break
            except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError):
                pass
            time.sleep(0.2)
        assert checkpoint is not None, 'Fresh native normal-Settings fixture checkpoint missing; inspect same producer'
        code = process.wait(timeout=300)
    finally:
        (base / (prefix + '-driver-observations.json')).write_text(json.dumps({
            'source': a.source, 'build': a.build, 'checkpoint': checkpoint, 'before': before,
            'producerPID': process.pid, 'producerExitCode': process.poll(),
            'scope': 'DEBUG normal-Root fixture with background Health/Watch sync withheld; real Settings and Files importer path. No physical-device/background-delivery proof.'
        }, indent=2) + '\n')
summary = json.loads(subprocess.check_output(['xcrun', 'xcresulttool', 'get', 'test-results', 'summary',
                                             '--path', str(result)], text=True))
(raw / (stem + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
(base / (prefix + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
assert code == 0 and summary['passedTests'] == 1 and summary['failedTests'] == 0
identity()
after = originals(container('group.com.dbakp.lumen'), checkpoint)
assert before == after
(base / (prefix + '-host-audit.json')).write_text(json.dumps({
    'status': 'baseline defect reproduced: valid selected input rejected because current Water is unavailable',
    'source': a.source, 'build': a.build, 'case': a.case, 'before': before, 'after': after,
    'verifierSHA256': digest(Path(__file__).read_bytes()),
    'scope': 'Native test asserts the specific saved-health-data-unavailable error, not a wrong password or invalid archive. Exact original seven canonical files and absent receipt independently checked. Product recovery is NOT accepted; private source ownership during review needs separate held-work tests.'
}, indent=2) + '\n')
print('REPRODUCED:', a.case, 'actual Files input rejected; seven original files unchanged')
